//
// Created by yuval on 01-Oct-21.
//

#ifndef DENSE_H
#define DENSE_H

#include "Activation.h"

// Insert Dense class here...


#endif //DENSE_H
